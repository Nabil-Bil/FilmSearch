 <section class="flex justify-center my-48">
        <p class="text-5xl font-bold">Not Found</p>
 </section>

