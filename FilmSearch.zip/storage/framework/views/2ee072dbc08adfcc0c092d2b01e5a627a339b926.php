<?php $__env->startSection('title'); ?>
    Best Films
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section class="m-10">
        <?php if($response->getStatusCode()==200): ?>
            <p class="sm:text-5xl text-2xl font-bold my-10 m-auto">Best Films :
            <p>
            <?php echo $__env->make("partials.item", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="flex justify-center">
                <?php if($id==$response['total_pages']): ?>
                    <a href="<?php echo e($id-=1); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
                <?php elseif($id==1): ?>
                    <a href="<?php echo e($id+=1); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>

                <?php else: ?>
                    <a href="<?php echo e($id-=1); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
                    <a href="<?php echo e($id+=2); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>
                <?php endif; ?>
            </div>


        <?php else: ?>
            <?php echo $__env->make('partials.notFound', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>

    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\FilmSearch\resources\views/bestFilm.blade.php ENDPATH**/ ?>