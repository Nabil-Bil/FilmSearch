<?php $__env->startSection('title'); ?>
<?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>

    <?php if($response->getStatusCode()==200): ?>
        <div class="container  sm:m-auto flex flex-col items-center">
            <h1 class="font-bold text-3xl mt-10 text-center"><?php echo e($title); ?></h1>
            <?php if($response['poster_path']!=""): ?>
                <img src="<?php echo e($image.$response['poster_path']); ?>" alt="Poster du film '<?php echo e($response['title']); ?>'" class="w-48 mt-10">
            <?php endif; ?>
            <p class="font-bold sm:text-xl text-lg mt-10 text-center"><?php echo e($response['overview']); ?></p>
            <div class="container m-auto flex sm:flex-row flex-col sm:justify-around items-center mt-10">
                <p class="font-bold text-gray-400 text-lg">Note : <?php echo e($response['vote_average']); ?>/10</p>
                <p class="font-bold  text-lg">Release Date : <?php echo e(date('d-m-Y',strtotime($response["release_date"]))); ?></p>
                <p class="font-bold text-lg">Revenue : <?php echo e($response["revenue"]); ?> $</p>
            </div>
        </div>
    <?php else: ?>
        <?php echo $__env->make('partials.notFound', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\FilmSearch\resources\views/film.blade.php ENDPATH**/ ?>