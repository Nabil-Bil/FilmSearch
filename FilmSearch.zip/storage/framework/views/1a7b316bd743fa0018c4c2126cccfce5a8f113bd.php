<?php $__currentLoopData = $response['results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="my-10 border-solid border-blue-500 md:border-4 md:rounded-xl md:p-10 border-b-4 pb-10 flex sm:flex-row flex-col items-center xl:mx-48 ">
        <?php if($item['poster_path']!=""): ?>
            <img src="<?php echo e($image.$item['poster_path']); ?>" alt="Poster du film '<?php echo e($item['title']); ?>'" class="md:w-48 w-32">
        <?php endif; ?>
        <div class="sm:ml-10 w-full flex flex-col  sm:items-start items-center mt-10">
            <a href="<?php echo e(route('film',$item['id'])); ?>" class="md:text-3xl text-xl font-bold"><?php echo e($item['title']); ?>:</a>
            <p class="mt-6 md:text-xl text-lg h-7 overflow-hidden"><?php echo e($item['overview']); ?></p>
            <div class="flex justify-between items-center sm:flex-row flex-col mt-12 w-full">
                <p class="md:text-xl text-lg font-bold text-gray-500">Note : <?php echo e($item['vote_average']); ?>/10</p>
                <?php if(array_key_exists('release_date',$item)): ?>
                    <p class="md:text-xl text-lg font-bold ">Release date : <?php echo e(date('d-m-Y',strtotime($item["release_date"]))); ?></p>

                <?php endif; ?>

            </div>


        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php /**PATH C:\wamp64\www\project\FilmSearch\resources\views/partials/item.blade.php ENDPATH**/ ?>