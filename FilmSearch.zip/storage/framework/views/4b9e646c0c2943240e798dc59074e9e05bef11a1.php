<?php $__env->startSection('title'); ?>
    SF <?php echo e($title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <?php if(empty($response['results'])): ?>

        <?php echo $__env->make('partials.notFound', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <section class="m-10">
            <?php if($id >0 and $id<=$response['total_pages']): ?>
                <p class="sm:text-5xl text-xl font-bold my-10 m-auto">Liste Films:
                <p>
                <?php echo $__env->make("partials.item", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="flex justify-center">
                    <?php if($id==$response['total_pages']): ?>
                        <a href="<?php echo e($id-=1); ?><?php echo e("?Film=$title"); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
                    <?php elseif($id==1): ?>
                        <a href="<?php echo e($id+=1); ?><?php echo e("?Film=$title"); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>

                    <?php else: ?>
                        <a href="<?php echo e($id-=1); ?><?php echo e("?Film=$title"); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
                        <a href="<?php echo e($id+=2); ?><?php echo e("?Film=$title"); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>
                    <?php endif; ?>
                </div>


            <?php else: ?>
                <?php echo $__env->make('partials.notFound', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

        </section>
    <?php endif; ?>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\project\FilmSearch\resources\views/listfilms.blade.php ENDPATH**/ ?>