<div class="flex justify-center">
    <?php if($id==$response['total_pages']): ?>
        <a href="<?php echo e($id-=1); ?><?php echo e($film); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
    <?php elseif($id==1): ?>
        <a href="<?php echo e($id+=1); ?><?php echo e($film); ?>" class="text-xl font-bold bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>

    <?php else: ?>
        <a href="<?php echo e($id-=1); ?><?php echo e($film); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Previous</a>
        <a href="<?php echo e($id+=2); ?><?php echo e($film); ?>" class="text-xl font-bold mx-5 bg-blue-400 px-10 py-2 rounded-full text-white">Next</a>
    <?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\project\FilmSearch\resources\views/partials/navigation.blade.php ENDPATH**/ ?>